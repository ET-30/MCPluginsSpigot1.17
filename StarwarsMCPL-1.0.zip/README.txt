Dependancies:

Download Skript & SKQuery:
https://github.com/SkriptLang/Skript/releases
https://www.spigotmc.org/resources/skquery-1-13-1-19.36631/

========================================

Install:

place "Starwars.sk" in the "plugins/skript/scripts" folder
install the "StarWarsResourcepack"
run command "/sk reload Starwars.sk" or restart the server

========================================

Commands:

/starwarsgive <Player> <lightsaber>:
 -redlightsaber
 -bluelightsaber
 -greenlightsaber
 -purplelightsaber
 -doublelightsaber
 -darksaber
 -angledlightsaber
 -lightrapier
 -throwingsaber

========================================

how to play:

sneak = block (holding the lightsaber also has a chance of passively blocking attacks)
rightclick = use ability (WIP)
swap item hand = force jump (WIP)

========================================

force abilities:
 (WIP)
 set lore of regular lightsabers (Blue, Green, Red, & Purple) to "Push" "Dash" or "Choke"
 set lore of double lightsaber to "Spin"
